from django.test import TestCase

# Create your tests here.
# for i in range(0,10):
#     pass
# print(i)
# a='5f'
# if a.isdigit():
#     print('True')
# import subprocess
# res=subprocess.run('ipconfig',)
#
# print(type(res))
if True:
    if 1<2:
        print(1)
    elif 1>2:
        print(2)
    else:
        print(3)
    for i in [1,2]:
        print(i)
